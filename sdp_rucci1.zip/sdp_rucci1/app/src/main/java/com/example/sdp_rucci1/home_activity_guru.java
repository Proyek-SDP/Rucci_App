package com.example.sdp_rucci1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class home_activity_guru extends AppCompatActivity {

    TextView tv1,tv2,tv3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_guru);
        tv1 = findViewById(R.id.textView63);
        tv2 = findViewById(R.id.textView62);
        tv3 = findViewById(R.id.textView61);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buatKelas();
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buatQuiz();
            }
        });
        tv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buatLesprivat();
            }
        });
    }
    public void buatKelas(){
        Intent i = new Intent(home_activity_guru.this,buatkelas_activity_guru.class);
        startActivity(i);
    }
    public void buatQuiz(){
        Intent i = new Intent(home_activity_guru.this,buatquiz_activity_guru.class);
        startActivity(i);
    }
    public void buatLesprivat(){
        Intent i = new Intent(home_activity_guru.this,buatles_activity_guru.class);
        startActivity(i);
    }
    public void liatKelas(View v){
        Intent i = new Intent(home_activity_guru.this,lihatkelas_activity_guru.class);
        startActivity(i);
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuKeluar){
            Intent i = new Intent(home_activity_guru.this,login_activity.class);
            startActivity(i);
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu_guru,menu);
        return true;
    }
}
