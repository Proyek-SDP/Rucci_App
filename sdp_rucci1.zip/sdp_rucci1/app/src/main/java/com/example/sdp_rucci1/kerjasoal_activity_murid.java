package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class kerjasoal_activity_murid extends AppCompatActivity {

    RadioButton rb1,rb2,rb3,rb4,rb5;
    RadioGroup rg1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kerjasoal_murid);
        rg1 = findViewById(R.id.radioGroup);
        tv1 = findViewById(R.id.textView38);
        rb1 = findViewById(R.id.rbA);
        rb2 = findViewById(R.id.rbB);
        rb3 = findViewById(R.id.rbC);
        rb4 = findViewById(R.id.rbD);
        rb5 = findViewById(R.id.rbE);

        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == rb1.getId()){
                    showBenar();
                }
                else{
                    showSalah();
                }
            }
        });
    }
    public void showBenar(){
        tv1.setText("Jawaban Benar! \n Penjelasan : \n 1 + 1 = 2 .");
        tv1.setTextColor(Color.BLACK);
        rb1.setTextColor(Color.GREEN);
    }
    public void showSalah(){
        tv1.setText("Jawaban Salah! \n Jawaban : A \nPenjelasan : \n 1 + 1 = 2 .");
        tv1.setTextColor(Color.RED);
        rb1.setTextColor(Color.GREEN);
    }
}
