package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class register_activity_guru extends AppCompatActivity {

    CheckBox cb1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_guru);
        btn1 = findViewById(R.id.button20);
        cb1 = findViewById(R.id.checkBox);
        btn1.setEnabled(false);
        cb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((CheckBox)v).isChecked();
                if(checked){
                    btn1.setEnabled(true);
                    cb1.setTextColor(Color.WHITE);
                }
                else{
                    btn1.setEnabled(false);
                    cb1.setTextColor(Color.RED);
                }
            }
        });
    }
    public void daftar(View v){
        Intent i = new Intent(register_activity_guru.this,home_activity_guru.class);
        startActivity(i);
    }
}
