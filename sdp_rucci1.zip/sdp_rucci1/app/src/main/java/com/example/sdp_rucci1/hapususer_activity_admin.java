package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class hapususer_activity_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hapususer_admin);
    }
    public void hapus(View v){
        Intent i = new Intent(hapususer_activity_admin.this,home_activity_admin.class);
        startActivity(i);
    }
}
