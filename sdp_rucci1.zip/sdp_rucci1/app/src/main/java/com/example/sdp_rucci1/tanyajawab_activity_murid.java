package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class tanyajawab_activity_murid extends AppCompatActivity {

    Button btn1;
    ArrayList<TextView>  arrtv = new ArrayList<>();
    int ctr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tanyajawab_murid);
        btn1 = findViewById(R.id.button13);
        arrtv.add((TextView) findViewById(R.id.textView40));
        arrtv.add((TextView) findViewById(R.id.textView41));
        arrtv.add((TextView) findViewById(R.id.textView42));
        ctr = 0;
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setVisibility(View.INVISIBLE);
            arrtv.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gojawab();
                }
            });
        }
    }
    public void tanya(View v){
        arrtv.get(ctr).setVisibility(View.VISIBLE);
        if(ctr+1<3){
            ctr++;
        }
    }
    public void gojawab(){
        Intent i = new Intent(tanyajawab_activity_murid.this,jawab_activity_murid.class);
        startActivity(i);
    }
}
