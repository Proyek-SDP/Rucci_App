package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class login_activity extends AppCompatActivity {

    Button btn ;
    TextView tv;
    EditText et;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);
        btn = findViewById(R.id.button15);
        tv = findViewById(R.id.textView55);
        et = findViewById(R.id.editText9);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goRegister();
            }
        });
    }
    public void login(View v){
        if(et.getText().toString().equals("admin")){
            Intent i = new Intent(login_activity.this,home_activity_admin.class);
            startActivity(i);
        }
        else if(et.getText().toString().equals("murid")){
            Intent i = new Intent(login_activity.this,home_activity_murid.class);
            startActivity(i);
        }
        else if(et.getText().toString().equals("guru")){
            Intent i = new Intent(login_activity.this,home_activity_guru.class);
            startActivity(i);
        }
    }
    public void goRegister(){
        Intent i = new Intent(login_activity.this,register_activity.class);
        startActivity(i);
    }
}
