package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class joinkelas_activity_murid extends AppCompatActivity {

    TextView tv1,tv2,tv3,tv4,tv5,tv6;
    ArrayList<TextView> arrtv = new ArrayList<>();
    Button btn1;
    int ctr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joinkelas_murid);
        ctr = 0;
        tv1 = findViewById(R.id.textView11);
        tv2 = findViewById(R.id.textView12);
        tv3 = findViewById(R.id.textView13);
        tv4 = findViewById(R.id.textView14);
        tv5 = findViewById(R.id.textView15);
        tv6 = findViewById(R.id.textView16);
        btn1 = findViewById(R.id.button2);

        arrtv.add(tv1);
        arrtv.add(tv2);
        arrtv.add(tv3);
        arrtv.add(tv4);
        arrtv.add(tv5);
        arrtv.add(tv6);
        for (int i = 0; i < 6 ; i++) {
            arrtv.get(i).setVisibility(View.INVISIBLE);
            arrtv.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goKelas();
                }
            });
        }
    }
    public void join(View v){
        arrtv.get(ctr).setVisibility(View.VISIBLE);
        if(ctr+1<=5){
            ctr++;
        }
    }
    public void goKelas(){
        Intent i = new Intent(joinkelas_activity_murid.this,kelas_activity_murid.class);
        startActivity(i);
    }
}
