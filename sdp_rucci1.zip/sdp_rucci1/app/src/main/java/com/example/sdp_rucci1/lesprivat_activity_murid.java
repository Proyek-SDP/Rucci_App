package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class lesprivat_activity_murid extends AppCompatActivity {

    Button btn1,btn2;
    TextView tv1,tv2,tv3;
    ArrayList<TextView> arrtv = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesprivat_murid);
        btn1 = findViewById(R.id.button11);
        btn2 = findViewById(R.id.button12);
        tv1 = findViewById(R.id.textView23);
        tv2 = findViewById(R.id.textView24);
        tv3 = findViewById(R.id.textView25);
        arrtv.add(tv1);
        arrtv.add(tv2);
        arrtv.add(tv3);
        for (int i = 0; i <arrtv.size() ; i++) {
            arrtv.get(i).setVisibility(View.INVISIBLE);
        }
        Spinner spinner = (Spinner) findViewById(R.id.spinner6);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.kelas_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        Spinner spinner1 = (Spinner) findViewById(R.id.spinner7);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.pel_array, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(lesprivat_activity_murid.this,transaksi_activity_murid.class);
                    startActivity(i);
                }
            });
        }
    }
    public void single(View v){
        btn1.setBackgroundColor(Color.GRAY);
        btn2.setBackgroundColor(Color.WHITE);
        btn1.setEnabled(false);
        btn2.setEnabled(true);
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setText("Single "+ (i+1));
            arrtv.get(i).setVisibility(View.VISIBLE);
        }
    }
    public void group(View v){
        btn1.setBackgroundColor(Color.WHITE);
        btn2.setBackgroundColor(Color.GRAY);
        btn1.setEnabled(true);
        btn2.setEnabled(false);
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setText("Group "+ (i+1));
            if(i == 0){
                arrtv.get(i).setVisibility(View.VISIBLE);
            }
            else{
                arrtv.get(i).setVisibility(View.INVISIBLE);
            }
        }
    }
}
