package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class lihatkelas_activity_guru extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihatkelas_guru);
    }
}
