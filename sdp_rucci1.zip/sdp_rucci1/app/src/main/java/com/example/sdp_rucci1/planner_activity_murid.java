package com.example.sdp_rucci1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothClass;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class planner_activity_murid extends AppCompatActivity {

    EditText et;
    CalendarView cv;
    String notif;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planner_murid);
        et = findViewById(R.id.editText7);
        cv = findViewById(R.id.calendarView);
        cv.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                notif = dayOfMonth+"/"+month+"/"+year;
            }
        });
    }
    public void add(View v){
        String n = "Menambahkan plan " + et.getText().toString()+" pada "+notif;
        Toast.makeText(this, n, Toast.LENGTH_SHORT).show();
    }
}
