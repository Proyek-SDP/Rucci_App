package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    CheckBox cb1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.button5);
        cb1 = findViewById(R.id.cbSetuju);
        tv1 = findViewById(R.id.textView3);
        btn1.setEnabled(false);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
        R.array.kelas_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        tv1.setTextColor(Color.RED);

        cb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((CheckBox)v).isChecked();
                if(checked){
                    btn1.setEnabled(true);
                    tv1.setTextColor(Color.WHITE);
                }
                else{
                    btn1.setEnabled(false);
                    tv1.setTextColor(Color.RED);
                }
            }
        });
    }
    public void daftar(View v){
        Intent i = new Intent(MainActivity.this,register_activity_murid1.class);
        startActivity(i);
    }
}
