package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class jawab_activity_murid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jawab_murid);
    }
    public void jawab(View v){
        Intent i =new Intent(jawab_activity_murid.this,tanyajawab_activity_murid.class);
        startActivity(i);
    }
}
