package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class groupchat_activity_murid extends AppCompatActivity {

    ArrayList<TextView> arrtv = new ArrayList<>();
    EditText et;
    int ctr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groupchat_murid);
        et = findViewById(R.id.editText8);
        arrtv.add((TextView)findViewById(R.id.textView50));
        arrtv.add((TextView)findViewById(R.id.textView51));
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setVisibility(View.INVISIBLE);
        }
        ctr = 0;
    }
    public void send(View v){
        arrtv.get(ctr).setText(et.getText().toString());
        arrtv.get(ctr).setVisibility(View.VISIBLE);
        et.setText("");
        if(ctr+1<2){
            ctr++;
        }
    }
}
