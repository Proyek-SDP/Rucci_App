package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;

public class banksoal_activity_murid extends AppCompatActivity {

    ArrayList<TextView> tv1 = new ArrayList<>();
    ArrayList<String> arrsoal = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banksoal_murid);
        Collections.addAll(arrsoal,getResources().getStringArray(R.array.banksoal_array));
        tv1.add((TextView)findViewById(R.id.textView26));
        tv1.add((TextView)findViewById(R.id.textView27));
        tv1.add((TextView)findViewById(R.id.textView28));
        tv1.add((TextView)findViewById(R.id.textView29));
        tv1.add((TextView)findViewById(R.id.textView30));
        tv1.add((TextView)findViewById(R.id.textView31));
        tv1.add((TextView)findViewById(R.id.textView32));
        tv1.add((TextView)findViewById(R.id.textView33));
        tv1.add((TextView)findViewById(R.id.textView34));
        tv1.add((TextView)findViewById(R.id.textView35));

        for (int i = 0; i < arrsoal.size(); i++) {
            tv1.get(i).setText(arrsoal.get(i));
            tv1.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goSoal();
                }
            });
        }
    }
    public void goSoal(){
        Intent i = new Intent(banksoal_activity_murid.this,kerjasoal_activity_murid.class);
        startActivity(i);
    }
}
