package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class tryout_activity_murid extends AppCompatActivity {

    TextView tv1,tv2,tv3,tv4,tv5;
    ArrayList<TextView> arrtv = new ArrayList<>();
    ArrayList<String> arrpel = new ArrayList<>();
    ArrayList<String> arrtahun = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tryout_murid);
        final Spinner spinner = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.pel_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        tv1 = findViewById(R.id.textView18);
        tv2 = findViewById(R.id.textView19);
        tv3 = findViewById(R.id.textView20);
        tv4 = findViewById(R.id.textView21);
        tv5 = findViewById(R.id.textView22);
        arrtv.add(tv1);
        arrtv.add(tv2);
        arrtv.add(tv3);
        arrtv.add(tv4);
        arrtv.add(tv5);
        for (int i = 0; i < arrtv.size(); i++) {
            arrtv.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goSoal();
                }
            });
        }
        Collections.addAll(arrpel,getResources().getStringArray(R.array.pel_array));
        Collections.addAll(arrtahun,getResources().getStringArray(R.array.peltahun_array));

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                for (int i = 0; i < arrtv.size(); i++) {
                    arrtv.get(i).setText(arrpel.get(position)+ " " + arrtahun.get(i));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public void goSoal(){
        Intent i = new Intent(tryout_activity_murid.this,kerjasoal_activity_murid.class);
        startActivity(i);
    }
}
