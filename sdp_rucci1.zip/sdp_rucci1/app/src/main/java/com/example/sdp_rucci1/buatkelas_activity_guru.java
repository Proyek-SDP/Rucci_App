package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class buatkelas_activity_guru extends AppCompatActivity {

    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buatkelas_guru);
        tv = findViewById(R.id.textView64);
        tv.setVisibility(View.INVISIBLE);
    }
    public void buatKelas(View v){
        tv.setVisibility(View.VISIBLE);
    }
}
