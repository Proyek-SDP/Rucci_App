package com.example.sdp_rucci1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class home_activity_murid extends AppCompatActivity {

    Button btn1,btn2,btn3,btn4,btn5,btn6;
    TextView tv1,tv2,tv3;
    ArrayList<String> arr_kelas = new ArrayList<>();
    ArrayList<Button> arrbtn = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_murid);
        btn1 = findViewById(R.id.button4);
        btn2 = findViewById(R.id.button6);
        btn3 = findViewById(R.id.button7);
        btn4 = findViewById(R.id.button8);
        btn5 = findViewById(R.id.button9);
        btn6 = findViewById(R.id.button10);
        arrbtn.add(btn1);
        arrbtn.add(btn2);
        arrbtn.add(btn3);
        arrbtn.add(btn4);
        arrbtn.add(btn5);
        arrbtn.add(btn6);
        for (int i = 0; i < arrbtn.size(); i++) {
            arrbtn.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bankSoal();
                }
            });
        }
        tv1 = findViewById(R.id.textView8);
        tv2 = findViewById(R.id.textView9);
        tv3 = findViewById(R.id.textView10);
        arr_kelas.add("10 IPA");
        arr_kelas.add("10 IPS");
        arr_kelas.add("11 IPA");
        arr_kelas.add("11 IPS");
        arr_kelas.add("12 IPA");
        arr_kelas.add("12 IPS");
        Spinner spinner = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.kelas_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(arr_kelas.get(position).substring(3,6).equals("IPA")){
                    btn1.setText("Matematika IPA");
                    btn2.setText("Fisika");
                    btn3.setText("Biologi");
                    btn4.setText("Kimia");
                    btn5.setText("B.Inggris");
                }
                else{
                    btn1.setText("Matematika IPS");
                    btn2.setText("Ekonomi");
                    btn3.setText("Sosiologi");
                    btn4.setText("Geografi");
                    btn5.setText("Sejarah");
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                joinKelas();
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tryOut();
            }
        });
        tv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lesPrivat();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuGroupchat){
            groupChat();
        }
        else if(item.getItemId() == R.id.menuLastactivity){
            lastActivity();
        }
        else if(item.getItemId() == R.id.menuPlanner){
            planner();
        }
        else if(item.getItemId() == R.id.menuTanyajawab){
            tanyaJawab();
        }
        else if(item.getItemId() == R.id.menuKeluar){
            keluar();
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu_murid,menu);
        return true;
    }

    public void joinKelas(){
        Intent i = new Intent(home_activity_murid.this,joinkelas_activity_murid.class);
        startActivity(i);
    }
    public void tanyaJawab(){
        Intent i = new Intent(home_activity_murid.this,tanyajawab_activity_murid.class);
        startActivity(i);
    }
    public void tryOut(){
        Intent i = new Intent(home_activity_murid.this,tryout_activity_murid.class);
        startActivity(i);
    }
    public void bankSoal(){
        Intent i = new Intent(home_activity_murid.this,banksoal_activity_murid.class);
        startActivity(i);
    }
    public void planner(){
        Intent i = new Intent(home_activity_murid.this,planner_activity_murid.class);
        startActivity(i);
    }
    public void lesPrivat(){
        Intent i = new Intent(home_activity_murid.this,lesprivat_activity_murid.class);
        startActivity(i);
    }
    public void groupChat(){
        Intent i = new Intent(home_activity_murid.this,groupchat_activity_murid.class);
        startActivity(i);
    }
    public void lastActivity(){
        Intent i = new Intent(home_activity_murid.this,lastactivity_activity_murid.class);
        startActivity(i);
    }
    public void keluar(){
        Intent i = new Intent(home_activity_murid.this,login_activity.class);
        startActivity(i);
    }
}
