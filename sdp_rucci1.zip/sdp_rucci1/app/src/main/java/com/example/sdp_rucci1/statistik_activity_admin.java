package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class statistik_activity_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistik_admin);
    }
    public void liatStatistik(View v){
        Intent i = new Intent(statistik_activity_admin.this,home_activity_admin.class);
        startActivity(i);
    }
}
