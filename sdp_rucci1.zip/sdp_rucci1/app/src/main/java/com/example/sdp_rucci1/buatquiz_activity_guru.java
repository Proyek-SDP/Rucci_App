package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class buatquiz_activity_guru extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buatquiz_guru);
    }
    public void buatQuiz(View v){
        Intent i = new Intent(buatquiz_activity_guru.this,home_activity_guru.class);
        startActivity(i);
    }
}
