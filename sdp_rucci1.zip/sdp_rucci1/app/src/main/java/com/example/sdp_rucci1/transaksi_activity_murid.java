package com.example.sdp_rucci1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class transaksi_activity_murid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaksi_murid);
    }

    public void bayar(View v){
        Toast.makeText(this, "Berhasil transaksi", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(transaksi_activity_murid.this,home_activity_murid.class);
        startActivity(i);
    }
}
